echo "contents in current folder:"
ls