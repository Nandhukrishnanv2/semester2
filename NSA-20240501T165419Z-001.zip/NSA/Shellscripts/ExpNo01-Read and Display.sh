echo "Enter a string:"
read user_string
echo "You entered:$user_string"